package com.osman.vehicleservicesystem;

public class VehicleServiceSystem {
    public static void main(String[] args) {
        System.out.println("VehicleServiceSystem started.");
    }
}
